package com.logistica.repository;

import com.logistica.model.envios_maritimos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnvioMaritimoRepository extends JpaRepository<envios_maritimos, Long> {
}
