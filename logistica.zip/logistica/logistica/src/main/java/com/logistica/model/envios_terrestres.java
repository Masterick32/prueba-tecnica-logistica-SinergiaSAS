package com.logistica.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class envios_terrestres {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String tipoProducto;
    private int cantidad;
    private LocalDate fechaRegistro;
    private LocalDate fechaEntrega;
    private double precioEnvio;
    private String placaVehiculo;
    private String numeroGuia;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    // Constructor vacío
    public envios_terrestres() {}

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTipoProducto() { return tipoProducto; }
    public void setTipoProducto(String tipoProducto) { this.tipoProducto = tipoProducto; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public LocalDate getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDate fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public LocalDate getFechaEntrega() { return fechaEntrega; }
    public void setFechaEntrega(LocalDate fechaEntrega) { this.fechaEntrega = fechaEntrega; }

    public double getPrecioEnvio() { return precioEnvio; }
    public void setPrecioEnvio(double precioEnvio) { this.precioEnvio = precioEnvio; }

    public String getPlacaVehiculo() { return placaVehiculo; }
    public void setPlacaVehiculo(String placaVehiculo) { this.placaVehiculo = placaVehiculo; }

    public String getNumeroGuia() { return numeroGuia; }
    public void setNumeroGuia(String numeroGuia) { this.numeroGuia = numeroGuia; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    // Método toString
    @Override
    public String toString() {
        return "envios_terrestres{" +
                "id=" + id +
                ", tipoProducto='" + tipoProducto + '\'' +
                ", cantidad=" + cantidad +
                ", fechaRegistro=" + fechaRegistro +
                ", fechaEntrega=" + fechaEntrega +
                ", precioEnvio=" + precioEnvio +
                ", placaVehiculo='" + placaVehiculo + '\'' +
                ", numeroGuia='" + numeroGuia + '\'' +
                ", cliente=" + cliente +
                '}';
    }
}
