package com.logistica.controller;

import com.logistica.model.envios_terrestres;
import com.logistica.repository.EnvioTerrestreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/envios_terrestres")
public class EnvioTerrestreController {
    @Autowired
    private EnvioTerrestreRepository envioTerrestreRepository;

    @GetMapping
    public List<envios_terrestres> getAllEnviosTerrestres() {
        return envioTerrestreRepository.findAll();
    }

    @PostMapping
    public envios_terrestres createEnvioTerrestre(@RequestBody envios_terrestres envio) {
        return envioTerrestreRepository.save(envio);
    }
}
