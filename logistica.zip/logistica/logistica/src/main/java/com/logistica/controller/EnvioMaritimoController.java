package com.logistica.controller;

import com.logistica.model.envios_maritimos;
import com.logistica.model.envios_maritimos;
import com.logistica.repository.EnvioMaritimoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/envios-maritimos")
public class EnvioMaritimoController {
    @Autowired
    private EnvioMaritimoRepository envioMaritimoRepository;

    @GetMapping
    public List<envios_maritimos> getAllEnviosMaritimos() {
        return envioMaritimoRepository.findAll();
    }

    @PostMapping
    public envios_maritimos createEnvioMaritimo(@RequestBody envios_maritimos envio) {
        return envioMaritimoRepository.save(envio);
    }
}
