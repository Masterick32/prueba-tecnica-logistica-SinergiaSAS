package com.logistica.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "envios_maritimos")
public class envios_maritimos {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_envio")
    private Long idEnvio;

    @ManyToOne
    @JoinColumn(name = "id_cliente")
    private Cliente cliente;

    @Column(name = "tipo_producto")
    private String tipoProducto;

    private int cantidad;

    @Column(name = "fecha_registro")
    private LocalDate fechaRegistro;

    @Column(name = "fecha_entrega")
    private LocalDate fechaEntrega;

    @Column(name = "puerto_entrega")
    private String puertoEntrega;

    @Column(name = "precio_envio")
    private double precioEnvio;

    @Column(name = "numero_flotilla", length = 8)
    private String numeroFlotilla;

    @Column(name = "numero_guia", length = 10, unique = true)
    private String numeroGuia;

    private double descuento;

    @Column(name = "precio_con_descuento")
    private double precioConDescuento;

    // Constructor vacío
    public envios_maritimos () {}

    // Getters y Setters
    public Long getIdEnvio() { return idEnvio; }
    public void setIdEnvio(Long idEnvio) { this.idEnvio = idEnvio; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public String getTipoProducto() { return tipoProducto; }
    public void setTipoProducto(String tipoProducto) { this.tipoProducto = tipoProducto; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public LocalDate getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDate fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public LocalDate getFechaEntrega() { return fechaEntrega; }
    public void setFechaEntrega(LocalDate fechaEntrega) { this.fechaEntrega = fechaEntrega; }

    public String getPuertoEntrega() { return puertoEntrega; }
    public void setPuertoEntrega(String puertoEntrega) { this.puertoEntrega = puertoEntrega; }

    public double getPrecioEnvio() { return precioEnvio; }
    public void setPrecioEnvio(double precioEnvio) { this.precioEnvio = precioEnvio; }

    public String getNumeroFlotilla() { return numeroFlotilla; }
    public void setNumeroFlotilla(String numeroFlotilla) { this.numeroFlotilla = numeroFlotilla; }

    public String getNumeroGuia() { return numeroGuia; }
    public void setNumeroGuia(String numeroGuia) { this.numeroGuia = numeroGuia; }

    public double getDescuento() { return descuento; }
    public void setDescuento(double descuento) { this.descuento = descuento; }

    public double getPrecioConDescuento() { return precioConDescuento; }
    public void setPrecioConDescuento(double precioConDescuento) { this.precioConDescuento = precioConDescuento; }
}
