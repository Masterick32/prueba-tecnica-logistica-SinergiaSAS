package com.logistica.repository;

import com.logistica.model.envios_terrestres;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnvioTerrestreRepository extends JpaRepository<envios_terrestres, Long> {
}
